from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, get_user_model
from django.views import generic
from django.views.generic import View

from .forms import LoginForm

def UserAuth (request):
    form = LoginForm(request.POST or None)
    user = get_user_model()
    if form.is_valid():
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        user = authenticate(username=username, password=password)

        if not user:
            raise forms.ValidationError("User does not exist")
        
        if not user.check_password(password):
            raise forms.ValidationError("Wrong password")

        if not user.is_active:
            raise forms.ValidationError("YOU ARE BANNED SUCCA")


        
    return render(request, 'staff/login_form.html', {'form': form})
