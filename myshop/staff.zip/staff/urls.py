from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.UserAuth.as_view(), name='auth'),
]
